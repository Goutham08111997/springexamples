package com.cognizant.springlearn;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import com.cognizant.springlearn.bean.*;
//import com.cognizant.springlearn.controller.EmployeeController;
//import com.cognizant.springlearn.controller.EmployeeController;


@SpringBootApplication
public class SpringLearnApplication {
    private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);
    

    public static void main(String[] args) throws ParseException {
        // SpringApplication.run(SpringLearnApplication.class, args);
        ApplicationContext applicationContext = SpringApplication.run(SpringLearnApplication.class, args);

        displayDate();
        displayCountry();
        displayCountries();
        displayEmployee();
       // displayUserController();
      
      //  displayEmployeeController();
     //displayEmployeeControllerAnnotation(applicationContext);
    
    }
    
    
    public static void displayDate() throws ParseException {
        ApplicationContext context = new ClassPathXmlApplicationContext("dateFormat.xml");
        SimpleDateFormat format = (SimpleDateFormat) context.getBean("dateFormat");
        Date today = format.parse("31/12/2018");
        // System.out.println("Date : " + today);
        LOGGER.debug("Date : {}", today.toString());
    }

    public static void displayCountry() {
        ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
        Country country = (Country) context.getBean("country");
        LOGGER.debug("Country : {}", country.toString());
    }

    public static void displayCountries() {
        ApplicationContext context = new ClassPathXmlApplicationContext("country-list.xml");
        List<Country> countryList = (ArrayList<Country>) context.getBean("countryList");
        // countryList.forEach(country->System.out.println(country));
        LOGGER.debug("CountryList = {}", countryList.toString());
    }

    public static void displayEmployee() {
        ApplicationContext context = new ClassPathXmlApplicationContext("app.xml");
        Employee employee = context.getBean("employee", Employee.class);
        LOGGER.debug("Employee : {}", employee.toString());
    }

    
  /* public static void displayEmployeeController() {
	   ApplicationContext context = new ClassPathXmlApplicationContext("employee.xml");
	   EmployeeController employeeController = context.getBean("employeeController",EmployeeController.class);
   }
   
   public static void displayEmployeeControllerAnnotation(ApplicationContext  applicationContext) {
       EmployeeController employeeController = (EmployeeController) applicationContext
               .getBean("employeeController");
       LOGGER.debug("EmployeeController : {}", employeeController.toString());

   }*/
}
