package com.cognizant.springlearn.bean;

import javax.validation.constraints.Min;
//import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Department {
    private static final Logger LOGGER = LoggerFactory.getLogger(Department.class);

    @Min(value=1,message="Department Id is Required")
    private int id;
    
    @NotNull(message="Department Name can not be Null")
  //  @NotEmpty(message="Department Name can not be empty")
    private String name;

    public Department() {
        LOGGER.debug("Department -Default Constructor");
    }
 
    public Department(int id, String name) {
        super();
        this.id = id;
        this.name = name;
    }

    public int getId() {
        LOGGER.debug("Getter Method : id = {}", Integer.toString(id));
        return id;
    }

    public void setId(int id) {
        LOGGER.debug("Setter Method : id = {}", Integer.toString(id));
        this.id = id;
    }

    public String getName() {
        LOGGER.debug("Getter Method : name = {}", name);
        return name;
    }

    public void setName(String name) {
        LOGGER.debug("Setter Method : name = {}", name);
        this.name = name;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Department [id=");
        builder.append(id);
        builder.append(", name=");
        builder.append(name);
        builder.append("]");
        return builder.toString();
    }

}
