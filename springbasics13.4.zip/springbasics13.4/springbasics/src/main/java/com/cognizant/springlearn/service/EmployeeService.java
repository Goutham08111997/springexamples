package com.cognizant.springlearn.service;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.bean.Employee;
import com.cognizant.springlearn.dao.EmployeeDao;
import com.cognizant.springlearn.service.exception.EmployeeNotFoundException;

@Component
public class EmployeeService {
    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeService.class);
    
    @Autowired
    
   private EmployeeDao employeeDao;
   
    public EmployeeService(){
    	
    	LOGGER.debug("DEFAULT CONS");
    }
    
    public EmployeeDao getEmployeeDao(){
    	LOGGER.debug("GETTER");
    	return employeeDao;
    }
    
    public void setEmployeeDao(EmployeeDao employeeDao){
    	LOGGER.info("start");
    	this.employeeDao = employeeDao;
    	LOGGER.info("end");
    }
    
    
    
    
    

}
