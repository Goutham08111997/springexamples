package com.cognizant.springlearn.controller;

import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.server.ResponseStatusException;

import com.cognizant.springlearn.bean.Employee;
import com.cognizant.springlearn.service.EmployeeService;
import com.cognizant.springlearn.service.exception.EmployeeNotFoundException;



@RestController
@RequestMapping("/employees")
public class EmployeeController{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeController.class);
	
	
	
	@Autowired
	private EmployeeService employeeService;
	
	
	public EmployeeController(){
		LOGGER.info("Start");
		
	}
	
	public  EmployeeService getEmployeeService(){
		LOGGER.info("Start");
		return employeeService;
	}
	
	
	public void setEmployeeService(EmployeeService employeeService) {
		LOGGER.info("Start");
		this.employeeService = employeeService;
	}
	
	
	
	@GetMapping()
	
	public ResponseEntity<Object> getEmployees(){
		LOGGER.info("Start");
		return new ResponseEntity<>(employeeService.getEmployeeDao().getAllEmployees(),HttpStatus.OK);
		
	}
	   
	@GetMapping("/{id}")
	public ResponseEntity<Object> getEmployee(@PathVariable("id") int employeeId){
		LOGGER.info("Start");
		   
		   return new ResponseEntity<>(employeeService.getEmployeeDao().getEmployee(employeeId),HttpStatus.OK);
		   
	   }
	
	
	
	
}
