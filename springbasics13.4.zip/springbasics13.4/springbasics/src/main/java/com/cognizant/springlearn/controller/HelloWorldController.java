package com.cognizant.springlearn.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {
	
	@RequestMapping("/hello")
	public String sayHello(){
		
		return "good Morning guys";
	}

	
	@RequestMapping("/hellowelcome")
	public String sayHello1(){
		
		return "good Noon ";
	}

	
	
}
