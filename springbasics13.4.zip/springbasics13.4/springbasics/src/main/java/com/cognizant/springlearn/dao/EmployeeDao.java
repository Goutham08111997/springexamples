package com.cognizant.springlearn.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.cognizant.springlearn.Country;
import com.cognizant.springlearn.bean.Department;
import com.cognizant.springlearn.bean.Employee;
import com.cognizant.springlearn.bean.Skill;
import com.cognizant.springlearn.service.exception.EmployeeNotFoundException;
import com.cognizant.springlearn.util.DateUtil;

@Component
public class EmployeeDao {
    private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeDao.class);
    
   private static List<Employee>  employeeList;
    
    public EmployeeDao(){
    	                      employeeList = new  ArrayList<Employee>();
    	                      
    	                      Skill[] skills = { new Skill(1, "HTML"), new Skill(2, "CSS"), new Skill(3, "javascript") };
    	                      employeeList.add(new Employee(1001, "Arun", 10000, true,
    	                              DateUtil.convertToDate("24/10/2000"), new Department(1, "HR"), skills));
    	                         	                      
    	                      employeeList.add(new Employee(1001, "Arjun", 20000, true,
    	                              DateUtil.convertToDate("21/12/2000"), new Department(1, "Payroll"), skills));
    	                      
    	                      
    	                      employeeList.add(new Employee(1001, "Karthik", 30000, false,
    	                              DateUtil.convertToDate("12/04/2001"), new Department(1, "Logistics"), skills));
    	                      
                           
    	                      
    	
    	
    }
    
    public  Employee getEmployee(int employeeId){
    
    	
    	   Employee result  = null; 
    	   Optional<Employee> obj = employeeList.stream().filter(emp -> emp.getId() == employeeId).findFirst();
    	
    	  result = obj.orElse(null);
    	
    	 
    	  return result;
    	
    }
    
    
    public List<Employee> getAllEmployees(){
    	return employeeList;
    }
        
    
    
}
