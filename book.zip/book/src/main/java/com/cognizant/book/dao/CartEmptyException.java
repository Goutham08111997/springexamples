package com.cognizant.book.dao;

@SuppressWarnings("serial")
public class CartEmptyException extends Exception {
	public CartEmptyException() {
		super();
	}

}
