package com.cognizant.book.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.book.bean.MenuItem;
import com.cognizant.book.bean.Role;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem, Integer> {
	//MenuItem findById(int id);
	@Query(value = "select * from book.menu_item where me_active = '1' && me_date_of_publication < \"2019-01-01\"", nativeQuery = true)
	List<MenuItem> getMenuItem();

	public Optional<MenuItem> findById(int menuItemId);
	
}
