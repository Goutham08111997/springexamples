package com;
 
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
 
import java.util.ArrayList;
import java.util.List;
 
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.*;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.MockitoAnnotations;
//import org.mockito.junit.MockitoJUnitRunner;
import static org.mockito.Mockito.*; 
 
import com.demo.dao.EmployeeDao;
import com.demo.model.EmployeeVO;
import com.demo.service.EmployeeManager;
 
//@RunWith(MockitoJUnitRunner.class)
public class TestEmployeeManager {
     
    @InjectMocks
    EmployeeManager manager;
     
    @Mock
    EmployeeDao dao;   
 
    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
    
    
         
    @Test
    public void getAllEmployeesTest()
    {
       
    	List<EmployeeVO> list = new ArrayList<EmployeeVO>();
        EmployeeVO empOne = new EmployeeVO(1, "Rajesh", "Kumar","raj@gmail.com");
        EmployeeVO empTwo = new EmployeeVO(2, "Aswin", "Kumar", "aswin@gmail.com");
        EmployeeVO empThree = new EmployeeVO(3, "Pavithra", "karthik", "pavithra@gmail.com");
         
        list.add(empOne);
        list.add(empTwo);
        list.add(empThree);
         
        
   
        
        
        when(dao.getEmployeeList()).thenReturn(list);
         
        //test
        List<EmployeeVO> empList = manager.getEmployeeList();
              
       // List empList1 = manager.getEmployeeList(); //to check for second call
        
        
        assertEquals(3, empList.size());
        
        verify(dao, times(1)).getEmployeeList();
    }
     
    
    @Test
    public void getEmployeeByIdTest()
    {
        when(dao.getEmployeeById(1)).thenReturn(new EmployeeVO(1,"Rajesh","Kumar","raj@email.com"));
         
        EmployeeVO emp = manager.getEmployeeById(1);
         
        assertEquals("Rajesh", emp.getFirstName());
        assertEquals("Kumar", emp.getLastName());
        assertEquals("raj@email.com", emp.getEmail());
    }
     
    
    @Test
    public void createEmployeeT()
    {
        EmployeeVO emp = new EmployeeVO(1,"Rajesh","Kumar","raj@gmail.com");
        
        manager.addEmployee(emp);
    
        verify(dao, times(1)).addEmployee(emp);
    }
    



   

}

