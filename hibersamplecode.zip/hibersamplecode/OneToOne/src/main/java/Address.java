//create table employee11(EmpId number(3),name varchar2(20),sal number(8,2),job varchar2(20),deptno number(3),AddressId number(2));
//create table address11(AddressId number(2),State varchar2(20),City varchar2(20),Street varchar2(20),Pincode number(9),Houseno number(2));
public class Address {
     
    private long addressId;
    private String street;
    private String state;
    private String city;
    private String pincode;
    private String houseno;
     
    public Address(String city, String state, String street,String pincode,String houseno) {
        this.city = city;
        this.pincode = pincode;
        this.state = state;
        this.street = street;
        this.houseno=houseno;
    }
        
    public String getHouseno() {
        return houseno;
    }
    public void setHouseno(String houseno) {
        this.houseno = houseno;
    }
        public long getAddressId() {
        return addressId;
    }
    public void setAddressId(long addressId) {
        this.addressId = addressId;
    }   
    public String getStreet() {
        return street;
    }
    public void setStreet(String street) {
        this.street = street;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getPincode() {
        return pincode;
    }
    public void setPincode(String pincode) {
        this.pincode = pincode;
    }
}