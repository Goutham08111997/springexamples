import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
//import org.util.HibernateUtil;
public class HibMain {
 
    public static void main(String[] args) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        
        Transaction transaction = null;
        try {
            
        	transaction = session.beginTransaction();
            	Employee employee=new Employee("Pavithra","IT",45000,10);
            
        
            Address address=new Address("Mv","TN","a.k.st","600444","43");
            
            employee.setEmployeeAddress(address);
            
            session.save(employee);
            transaction.commit();
            System.out.println("Pls c the table");
        } catch (HibernateException e) {
          transaction.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }
}