

import java.util.HashSet;

import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;





/*create table phone(phoneId number,phoneType varchar(30),phoneNumber varchar(30));
create table STUDENT_PHONE(studentPhoneNumbers varchar(30),STUDENT_ID number,PHONE_ID int);
select * from phone;
select * from STUDENT_PHONE;
create table student(studentId number,studentName varchar(30));
select * from student;
*
*/

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			
			Set<Phone> pnos = new HashSet<Phone>();
			pnos.add(new Phone("house","25332211"));
			pnos.add(new Phone("mobile","9003333846"));
	
			Set<Phone> pnos1=new HashSet<Phone>();
			pnos1.add(new Phone("house","44344445"));
			pnos1.add(new Phone("mobile","9043084800"));
			
			
			Student student = new Student("AswinK", pnos);
			session.save(student);
			Student st2=new Student("Ramki",pnos1);
			session.save(st2);
			
			transaction.commit();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
