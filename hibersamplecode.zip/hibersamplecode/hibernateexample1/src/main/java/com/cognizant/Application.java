package com.cognizant;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Application {

	public static void main(String[] args) {
		
		Student stud = new Student();
		
		stud.setSex("M");
		stud.setName("ArunKumar");
		stud.setId(101);
		stud.setLocation("chennai");
		
		
	    Configuration config = new Configuration().configure().addAnnotatedClass(Student.class);
	    
		
		SessionFactory sf = config.buildSessionFactory();
		
		Session session = sf.openSession();
		
		Transaction trans = session.beginTransaction();
		
		session.save(stud);
		
		stud = (Student) session.get(Student.class, 101);
		
        trans.commit();
        System.out.println(stud);
        
	}
}