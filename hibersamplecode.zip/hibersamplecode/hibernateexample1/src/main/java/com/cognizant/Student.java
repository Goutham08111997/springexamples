package com.cognizant;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Student {
	
	@Id
	private int id;
	private String name;
	private String sex;
	private String location;
	
	public String getLocation(){
		return location;
	}
	
	public void setLocation(String location) {
		this.location = location;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", sex=" + sex + " + location]";
	}
	

}
