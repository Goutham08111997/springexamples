package com.cognizant.springlearn;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class MainProgram {

	public static void main(String[] args) {
		
		/*Employee e1 = new Employee();
		e1.setEmpid(769889);
		e1.setName("Aswin");
		System.out.println(e1);
		*/
		/*Resource resource = new ClassPathResource("empbean.xml");
		
		BeanFactory factory = new XmlBeanFactory(resource);
		Employee e1 =  (Employee) factory.getBean("emp1");*/
		
		
		//System.out.println(e1);
		
		ApplicationContext context = new ClassPathXmlApplicationContext("empbean.xml");
		/*Employee e1 =  (Employee) context.getBean("emp1");
		
		System.out.println(e1);*/
		
		
		
		
		

	}

}
