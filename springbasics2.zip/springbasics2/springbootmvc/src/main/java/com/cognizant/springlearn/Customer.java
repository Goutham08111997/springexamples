package com.cognizant.springlearn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component 
public class Customer {

	private String id;
	private String name;
	
	@Autowired
	//@Qualifier("lap") 
	private Laptop laptop;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + "]";
	}
	public Customer(String id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public Customer() {
	System.out.println("object created");	
	}
	
	
	public void display() {
		System.out.println("am working");
		laptop.checkCondition();
	}
	
}


