package com.cognizant.springlearn.bean;

import java.util.Arrays;
import java.util.Date;

import javax.validation.Valid;
import javax.validation.constraints.Min;
//import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Employee {
    private static final Logger LOGGER = LoggerFactory.getLogger(Employee.class);
    
    
    //@NotNull(message ="Id can not be null")
    @Min(value=1,message="Id mandatory and greater than 0" )
  //  @Pattern(regexp = "[\\s]*[0-9]*[1-9]+", message="Should be a numeric value")
    private int id;
    
    @NotNull(message ="Name can not be null")
  //  @NotEmpty(message="Name can not be empty")
    @Size(min=2,max=10,  message="name length should be 2 to 10")
    private String name;
    
    @Min(value=1,message ="Salary is Required")
    private double salary;
    
    @NotNull(message ="Permanent is Required")
    private Boolean permanent;
    
    @NotNull(message ="DateOfBirth is Required")
   // @DateTimeFormat(iso=DateTimeFormat.ISO.DATE_TIME)
    //1994-11-15T18:30:00.000+0000"
   @JsonFormat(shape =JsonFormat.Shape.STRING,pattern = "dd/MM/yyyy") 
    private Date dateOfBirth;
    
    @NotNull(message ="Department is Required")
    @Valid
    private Department department;
    
    private Skill[] skills;

    public Employee() {
        LOGGER.debug("Employee - Default Constructor");
    }
    

    public Employee(int id, String name, double salary, boolean permanent, Date dateOfBirth,
            Department department, Skill[] skills) {
        super();
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.permanent = permanent;
        this.dateOfBirth = dateOfBirth;
        this.department = department;
        this.skills = skills;
    }


    public int getId() {
        LOGGER.debug("Getter Method : id = {}", Integer.toString(id));
        return id;
    }

    public void setId(int id) {
        LOGGER.debug("Setter Method : id = {}", Integer.toString(id));
        this.id = id;
    }

    public String getName() {
        LOGGER.debug("Getter Method : name = {}", name);
        return name;
    }

    public void setName(String name) {
        LOGGER.debug("Setter Method : name = {}", name);
        this.name = name;
    }

    public double getSalary() {
        LOGGER.debug("Getter Method : salary = {}", Double.toString(salary));
        return salary;
    }

    public void setSalary(double salary) {
        LOGGER.debug("Setter Method : salary = {}", Double.toString(salary));
        this.salary = salary;
    }

    public boolean isPermanent() {
        LOGGER.debug("Getter Method : permanent = {}", Boolean.toString(permanent));
        return permanent;
    }

    public void setPermanent(boolean permanent) {
        LOGGER.debug("Setter Method : permanent = {}", Boolean.toString(permanent));
        this.permanent = permanent;
    }

    public Date getDateOfBirth() {
        LOGGER.debug("Getter Method : dateOfBirth = {}", dateOfBirth.toString());
        return dateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        LOGGER.debug("Setter Method : dateOfBirth = {}", dateOfBirth.toString());
        this.dateOfBirth = dateOfBirth;
    }

    public Department getDepartment() {
        LOGGER.debug("Getter Method : department = {}", department.toString());
        return department;
    }

    public void setDepartment(Department department) {
        LOGGER.debug("Setter Method : department = {}", department.toString());
        this.department = department;
    }

    public Skill[] getSkills() {
        LOGGER.debug("Getter Method : skills = {}", Arrays.toString(skills));
        return skills;
    }

    public void setSkills(Skill[] skills) {
        LOGGER.debug("Setter Method : skills = {}", Arrays.toString(skills));
        this.skills = skills;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Employee [id=");
        builder.append(id);
        builder.append(", name=");
        builder.append(name);
        builder.append(", salary=");
        builder.append(salary);
        builder.append(", permanent=");
        builder.append(permanent);
        builder.append(", dateOfBirth=");
        builder.append(dateOfBirth);
        builder.append(", department=");
        builder.append(department);
        builder.append(", skills=");
        builder.append(Arrays.toString(skills));
        builder.append("]");
        return builder.toString();
    }

    /*
     * @Override public String toString() { return "Employee [id=" + id + ", name="
     * + name + ", salary=" + salary + ", permanent=" + permanent + ", dateOfBirth="
     * + dateOfBirth + "]"; }
     */

    /*
     * @Override public String toString() { return "Employee [id=" + id + ", name="
     * + name + ", salary=" + salary + ", permanent=" + permanent + ", dateOfBirth="
     * + dateOfBirth + ", department=" + department + "]"; }
     */

}
