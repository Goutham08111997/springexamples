package com.cognizant.springlearn.bean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Skill {
    private static final Logger LOGGER = LoggerFactory.getLogger(Skill.class);

    private int id;
    private String name;

    public Skill() {
        LOGGER.debug("Skill -Default Constructor");
    }
    

    public Skill(int id, String name) {
        super();
        this.id = id;
        this.name = name;
    }


    public int getId() {
        LOGGER.debug("Getter Method : id = {}", Integer.toString(id));
        return id;
    }

    public void setId(int id) {
        LOGGER.debug("Setter Method : id = {}", Integer.toString(id));
        this.id = id;
    }

    public String getName() {
        LOGGER.debug("Getter Method : name = {}", name);
        return name;
    }

    public void setName(String name) {
        LOGGER.debug("Setter Method : name = {}", name);
        this.name = name;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Skill [id=");
        builder.append(id);
        builder.append(", name=");
        builder.append(name);
        builder.append("]");
        return builder.toString();
    }

}
