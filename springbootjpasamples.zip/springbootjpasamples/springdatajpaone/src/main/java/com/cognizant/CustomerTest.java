package com.cognizant;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class CustomerTest {

	public static void main(String[] args) {
		   
		
		AnnotationConfigApplicationContext appC = new AnnotationConfigApplicationContext();
		appC.scan("com.cognizant");
		appC.refresh();
		
		CustomerService  cs =  (CustomerService) appC.getBean("customerService");
		cs.test();
		appC.close();
	}
}