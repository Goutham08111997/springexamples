package com.cognizant;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("customerService")
public class CustomerService {
	
	@Autowired
	private CustomerRepository repository;
	
public void test() {
    Customer newCustomer = new Customer();
	
	newCustomer.setFirstName("Arun");
	newCustomer.setLastName("Kumar");
	 
	repository.save(newCustomer);
	
	Optional<Customer> result  =  repository.findById(1L);
	result.ifPresent(customer -> System.out.println(customer));;
	
	
	List<Customer> customers  =  repository.findByLastName("Kumar");
	customers.forEach(customer -> System.out.println(customer));
	
	
	Iterable<Customer> iterator  =  repository.findAll();
	customers.forEach(customer -> System.out.println(customer));
	
		
}
	
	
}	
	
	
