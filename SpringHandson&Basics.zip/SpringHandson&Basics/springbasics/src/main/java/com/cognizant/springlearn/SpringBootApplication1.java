package com.cognizant.springlearn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class SpringBootApplication1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 
		ConfigurableApplicationContext context = SpringApplication.run(SpringBootApplication1.class, args);
		
		Customer c1 = context.getBean(Customer.class);
		c1.display();
		
		
		
	}

}

