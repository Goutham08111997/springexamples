package com.cognizant.springlearn;

public class Employee {
	
	private int empid;
	private String name;
	
	Address address;
		
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
		
	}
	
	public Employee(){
		System.out.println("object created");

	}
	
	//constructor injection
	public Employee(Address address){
     this.address = address;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	/*@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + "]";
	}*/
	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", name=" + name + ", address=" + address + "]";
	}
	
	
	
	
	

}
