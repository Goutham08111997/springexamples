package com.cognizant.book.authenticationservice.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Entity
@Table(name="menu_item")
public class MenuItem {
	private static final Logger LOGGER = LoggerFactory.getLogger(MenuItem.class);
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "me_id")
	int id;
	
	@Column(name = "me_name")
	String name;
	
	@Column(name = "me_price")
	//BigDecimal price;
	Float price;
	
	@Column(name = "me_active")
	boolean available;
	
	@Column(name = "me_date_of_publication")
	Date dateOfPublication;
	
	@Column(name = "me_category")
	String category;
	
	@Column(name = "me_free_delivery")
	boolean freeDelivery;
	
	@Column(name = "me_image")
	String image;

	public MenuItem() {
		LOGGER.info("START");
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	public boolean isActive() {
		return available;
	}

	public void setActive(boolean available) {
		this.available = available;
	}

	public Date getDateOfLaunch() {
		return dateOfPublication;
	}

	public void setDateOfLaunch(Date dateOfPublication) {
		this.dateOfPublication = dateOfPublication;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public boolean isFreeDelivery() {
		return freeDelivery;
	}

	public void setFreeDelivery(boolean freeDelivery) {
		this.freeDelivery = freeDelivery;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "id=" + id + ", name=" + name + ", price=" + price + ", available=" + available + ", dateOfPublication="
				+ dateOfPublication + ", category=" + category + ", freeDelivery=" + freeDelivery;
	}

}
