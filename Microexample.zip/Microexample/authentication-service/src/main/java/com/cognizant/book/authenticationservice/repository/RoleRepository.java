package com.cognizant.book.authenticationservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.book.authenticationservice.model.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, Integer>   {

	public Role findByName(String name);
}
