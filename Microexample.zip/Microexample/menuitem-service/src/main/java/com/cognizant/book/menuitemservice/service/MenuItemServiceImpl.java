package com.cognizant.book.menuitemservice.service;

import java.util.Date;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.book.menuitemservice.model.MenuItem;
import com.cognizant.book.menuitemservice.repository.MenuItemRepository;

@Service
public class MenuItemServiceImpl implements MenuItemService {

	private static final Logger LOGGER = LoggerFactory.getLogger(MenuItemServiceImpl.class);
	
	@Autowired
	MenuItemRepository menuItemRepository;

	@Override
	@Transactional
	public Set<MenuItem> getMenuItemListAdmin() {
		LOGGER.info("START");
		return menuItemRepository.getMenuItemListAdmin();
	}

	@Override
	@Transactional
	public Set<MenuItem> getMenuItemListCustomer() {
		LOGGER.info("START");
		return menuItemRepository.getMenuItemListCustomer(new Date());
	}

	@Override
	@Transactional
	public boolean modifyMenuItem(MenuItem menuItem) {
		LOGGER.info("START");
		boolean isModified = false;
		MenuItem item = menuItemRepository.save(menuItem);
		if (item != null) {
			isModified = true;
		}
		return isModified;
	}

	@Override
	@Transactional
	public MenuItem getMenuItem(int menuItemId) {
		LOGGER.info("START");
		return menuItemRepository.getMenuItem(menuItemId);
	}
}
