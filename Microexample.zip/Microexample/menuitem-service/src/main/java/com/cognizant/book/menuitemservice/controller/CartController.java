package com.cognizant.book.menuitemservice.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.book.menuitemservice.dto.CartDTO;
import com.cognizant.book.menuitemservice.exception.CartEmptyException;
import com.cognizant.book.menuitemservice.service.CartService;

@RestController
@RequestMapping("/book/carts")
public class CartController {
	private static final Logger LOGGER = LoggerFactory.getLogger(CartController.class);

	@Autowired
	CartService cartService;

	@PostMapping("/{userId}/{menuItemId}")
	public int addCartItem(@PathVariable String userId, @PathVariable int menuItemId) {
		LOGGER.info("START");
		return cartService.addCartItem(userId, menuItemId);
	}

	@GetMapping("/{userId}")
	public CartDTO getAllCartItems(@PathVariable String userId) throws CartEmptyException {
		LOGGER.info("START");
		return cartService.getAllCartItems(userId);
	}

	@DeleteMapping("/{userId}/{menuItemId}")
	public CartDTO deleteCartItems(@PathVariable String userId, @PathVariable int menuItemId)
			throws CartEmptyException {
		LOGGER.info("START");
		return cartService.removeCartItem(userId, menuItemId);
	}
}
