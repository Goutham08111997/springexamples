package com.cognizant.book.menuitemservice.service;

import com.cognizant.book.menuitemservice.dto.CartDTO;
import com.cognizant.book.menuitemservice.exception.CartEmptyException;

public interface CartService {
	public int addCartItem(String username, int menuItemId);

	public CartDTO getAllCartItems(String username) throws CartEmptyException;

	public CartDTO removeCartItem(String username, int menuItemId) throws CartEmptyException;
}
