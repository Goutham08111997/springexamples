package com.cognizant.book.menuitemservice.service;

import java.util.Optional;
import java.util.Set;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.book.menuitemservice.dto.CartDTO;
import com.cognizant.book.menuitemservice.exception.CartEmptyException;
import com.cognizant.book.menuitemservice.model.MenuItem;
import com.cognizant.book.menuitemservice.model.User;
import com.cognizant.book.menuitemservice.repository.MenuItemRepository;
import com.cognizant.book.menuitemservice.repository.UserRepository;

@Service
public class CartServiceImpl implements CartService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CartServiceImpl.class);
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	MenuItemRepository menuItemRepository;

	@Override
	@Transactional
	public int addCartItem(String username, int menuItemId) {
		LOGGER.info("START");
		int returnId = -1;
		User user = userRepository.findByUsername(username);
		Optional<MenuItem> menuItems = menuItemRepository.findById(menuItemId);
		if (menuItems.isPresent()) {
			user.getMenuItemList().add(menuItems.get());
			returnId = menuItemId;
		}
		userRepository.save(user);
		LOGGER.info("End");
		return returnId;
	}

	@Override
	@Transactional
	public CartDTO getAllCartItems(String username) throws CartEmptyException {
		LOGGER.info("START");
		User user = userRepository.findByUsername(username);
		Set<MenuItem> menuItemList = user.getMenuItemList();
		if (menuItemList.isEmpty())
			throw new CartEmptyException();
		double total = 0.0;
		for (MenuItem menuItem : menuItemList)
			total += menuItem.getPrice().doubleValue();
		LOGGER.info("End");
		return new CartDTO(menuItemList, total);
	}

	@Override
	@Transactional
	public CartDTO removeCartItem(String username, int menuItemId) throws CartEmptyException {
		LOGGER.info("START");
		User user = userRepository.findByUsername(username);
		Set<MenuItem> menuItemList = user.getMenuItemList();
		menuItemList.remove(menuItemRepository.findById(menuItemId).get());
		if (menuItemList.isEmpty())
			throw new CartEmptyException();
		double total = 0.0;
		for (MenuItem menuItem : menuItemList)
			total += menuItem.getPrice().doubleValue();
		LOGGER.info("End");
		return new CartDTO(menuItemList, total);
	}

}
