package com.cognizant.book.menuitemservice.service;

import java.util.Set;

import com.cognizant.book.menuitemservice.model.MenuItem;

public interface MenuItemService {
	public Set<MenuItem> getMenuItemListAdmin();

	public Set<MenuItem> getMenuItemListCustomer();

	public boolean modifyMenuItem(MenuItem menuItem);

	public MenuItem getMenuItem(int menuItemId);
}