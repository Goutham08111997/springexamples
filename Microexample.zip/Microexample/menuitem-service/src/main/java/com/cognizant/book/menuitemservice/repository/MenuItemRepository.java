package com.cognizant.book.menuitemservice.repository;

import java.util.Date;
import java.util.Optional;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.book.menuitemservice.model.MenuItem;

@Repository
public interface MenuItemRepository extends JpaRepository<MenuItem, Integer> {

	@Query(value = "select m from MenuItem m where m.dateOfLaunch <= ?1 and m.active = true")
	public Set<MenuItem> getMenuItemListCustomer(Date date);

	@Query(value = "select m from MenuItem m ")
	public Set<MenuItem> getMenuItemListAdmin();

	@Query(value = "select m from MenuItem m where m.id = ?1")
	public MenuItem getMenuItem(int menuItemId);

	public Optional<MenuItem> findById(int menuItemId); 
}
