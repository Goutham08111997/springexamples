package com.cognizant.book.menuitemservice.dto;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cognizant.book.menuitemservice.model.MenuItem;

public class CartDTO {
	private static final Logger LOGGER = LoggerFactory.getLogger(CartDTO.class);

	private Set<MenuItem> menuItemList;
	private double total;

	public CartDTO(Set<MenuItem> menuItemList, double total) {
		LOGGER.info("START");
		this.menuItemList = menuItemList;
		this.total = total;
	}

	public Set<MenuItem> getMenuItemList() {
		return menuItemList;
	}

	public void setMenuItemList(Set<MenuItem> menuItemList) {
		this.menuItemList = menuItemList;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	@Override
	public String toString() {
		return "Cart [menuItemList=" + menuItemList + ", total=" + total + "]";
	}
}
