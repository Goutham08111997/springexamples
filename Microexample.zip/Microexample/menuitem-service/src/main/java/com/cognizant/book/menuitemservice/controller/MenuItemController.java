package com.cognizant.book.menuitemservice.controller;

import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.book.menuitemservice.model.MenuItem;
import com.cognizant.book.menuitemservice.security.AppUserDetailsService;
import com.cognizant.book.menuitemservice.service.MenuItemService;

@RestController
@RequestMapping("/book/menu-items")
public class MenuItemController {

	private static final Logger LOGGER = LoggerFactory.getLogger(MenuItemController.class);

	@Autowired
	MenuItemService menuItemService;

	@Autowired
	AppUserDetailsService appUserDetailsService;

	@GetMapping()
	public Set<MenuItem> getAllMenuItems() {
		LOGGER.info("START");
		Set<MenuItem> menuItemList;
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String user = authentication.getName();
		LOGGER.debug("user : {}", user);

		if (!user.equals("anonymousUser")) {
			UserDetails userDetails = appUserDetailsService.loadUserByUsername(user);
			String role = userDetails.getAuthorities().toArray()[0].toString();
			LOGGER.debug("role : {}", role);

			if (role.equals("ADMIN")) {
				menuItemList = menuItemService.getMenuItemListAdmin();
			} else {
				menuItemList = menuItemService.getMenuItemListCustomer();
			}
		} else {
			menuItemList = menuItemService.getMenuItemListCustomer();
		}

		LOGGER.info("END");
		return menuItemList;
	}

	@GetMapping("/{id}")
	public MenuItem getMenuItem(@PathVariable int id) {
		LOGGER.info("START");
		return menuItemService.getMenuItem(id);
	}

	@PutMapping()
	public boolean modifyMenuItem(@RequestBody MenuItem menuItem) {
		LOGGER.info("START");
		return menuItemService.modifyMenuItem(menuItem);
	}

}
