package com.cognizant.ormlearn.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.exception.CountryNotFoundException;
import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.repository.CountryRepository;

@Service
public class CountryService {
	@Autowired
	private CountryRepository countryRepository;

	public List<Country> getAllCountries() {
		return countryRepository.findAll();
	}

	@Transactional
	public Country findCountryById(String id) throws CountryNotFoundException {
		Country country = null;
		Optional<Country> result = countryRepository.findById(id);
		if (result.isPresent()) {
			country = result.get();
			return country;
		} else {
			throw new CountryNotFoundException("Country Not Found");
		}
	}

	@Transactional
	public void addCountry(Country country) {
		countryRepository.save(country);
	}

	@Transactional
	public void updateCountry(Country country) {
		Optional<Country> result = countryRepository.findById(country.getCode());
		if (result.isPresent()) {
			countryRepository.save(country);
		}
	}

	@Transactional
	public void deleteCountry(String code) {
		countryRepository.deleteById(code);
	}

	@Transactional
	public List<Country> findCountriesContaining(String name) {
		return countryRepository.findByNameContaining(name);
	}
	
	@Transactional
	public List<Country> findCountriesContainingOrderByName(String name) {
		return countryRepository.findByNameContainingOrderByName(name);
	}
	
	@Transactional
	public List<Country> findCountriesStartingWith(String name){
		return countryRepository.findByNameStartingWithOrderByName(name);
	}
}
