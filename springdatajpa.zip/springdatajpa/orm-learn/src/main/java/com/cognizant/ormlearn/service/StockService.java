package com.cognizant.ormlearn.service;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.ormlearn.model.Stock;
import com.cognizant.ormlearn.repository.StockRepository;

@Service
public class StockService {

	@Autowired
	private StockRepository stockRepository;
	
	@Transactional
	public List<Stock> findByCodeAndDateBetween(String code, Date startDate, Date endDate){
		return stockRepository.findByCodeAndDateBetween(code, startDate, endDate);
	}
	
	
}
