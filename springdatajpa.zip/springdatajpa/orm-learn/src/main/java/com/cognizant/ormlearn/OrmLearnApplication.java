package com.cognizant.ormlearn;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.cognizant.ormlearn.exception.CountryNotFoundException;
import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.model.Skill;
import com.cognizant.ormlearn.model.Stock;
import com.cognizant.ormlearn.repository.StockRepository;
import com.cognizant.ormlearn.service.CountryService;
import com.cognizant.ormlearn.service.DepartmentService;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.SkillService;

@SpringBootApplication
public class OrmLearnApplication {
	private static final Logger LOGGER = LoggerFactory.getLogger(OrmLearnApplication.class);

	private static CountryService countryService;
	private static StockRepository stockRepository;
	private static EmployeeService employeeService;
	private static DepartmentService departmentService;
	private static SkillService skillService;

	public static void main(String[] args) throws CountryNotFoundException {
		ApplicationContext context = SpringApplication.run(OrmLearnApplication.class, args);
//		countryService = context.getBean(CountryService.class);
//		stockRepository = context.getBean(StockRepository.class);
		employeeService = context.getBean(EmployeeService.class);
		departmentService = context.getBean(DepartmentService.class);
		skillService = context.getBean(SkillService.class);
		LOGGER.info("Inside main");
//		testGetAllCountries();
//		testGetCountryById();
//		testAddCountry();
//		testUpdateCountry();
//		testDeleteCountry();
//		testFindByNameContaining();
//		testFindByNameContainingOrderByName();
//		testFindByNameStartingWith();
//		testFindByCodeAndDateBetween();
//		testFindByStockGreaterThan();
//		testFindTop3ByVolumeDesc();
//		testFindTop3ByVolumeAsc();
//		testGetEmployee();
//		testAddEmployee();
//		testUpdateEmployee();
//		testGetDepartment();
//		testAddSkill();
//		testGetAllPermanentEmployees();
//		testGetAverageSalary();
//		testGetAverageDeptSalary();
		testGetAllEmployeesNative();
	}
	
	public static void testGetAllEmployeesNative() {
		LOGGER.info("Start");
		List<Employee> employeeList = employeeService.getAllEmployeesNative();
		for (Employee employee : employeeList) {
			LOGGER.debug("employee:{}", employee);
		}
		LOGGER.info("End");
	}
	public static void testGetAverageSalary() {
		LOGGER.debug("Salary Average "+employeeService.getAverageSalary());
	}
	
	public static void testGetAverageDeptSalary() {
		LOGGER.debug("Salary Average "+employeeService.getAverageSalary(1));
	}

	public static void testGetAllPermanentEmployees() {
		LOGGER.info("Start");
		List<Employee> employeeList = employeeService.getAllPermanentEmployees();
		for (Employee employee : employeeList) {
			LOGGER.debug("employee:{}", employee);
		}
		LOGGER.info("End");
	}

	public static void testGetDepartment() {
		LOGGER.info("Start");
		Department department = departmentService.get(2);
		LOGGER.debug("department={}", department);
		LOGGER.debug("employees={}", department.getEmployeeList());
		LOGGER.info("End");
	}

	private static void testGetEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(1);
		LOGGER.debug("Employee:{}", employee);
		LOGGER.debug("Department:{}", employee.getDepartment());
		LOGGER.debug("Skills:{}", employee.getSkillList());
		LOGGER.info("End");
	}

	private static void testAddSkill() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(5);
		Skill skill = skillService.get(1);
		employee.getSkillList().add(skill);
		employeeService.save(employee);
		employee = employeeService.get(5);
		LOGGER.debug("Skills:{}", employee.getSkillList());
		LOGGER.info("End");
	}

	private static void testAddEmployee() {
		LOGGER.info("Start");
		Employee employee = new Employee();
		employee.setName("sai_hari98");
		employee.setPermanent(true);
		employee.setSalary(100000);
		employee.setDateOfBirth(new Date());
		Department department = departmentService.get(1);
		employee.setDepartment(department);
		employeeService.save(employee);
		LOGGER.debug("employee={}", employee);
		LOGGER.info("End");
	}

	private static void testUpdateEmployee() {
		LOGGER.info("Start");
		Employee employee = employeeService.get(5);
		employee.setName("Sairam H");
		Department department = departmentService.get(2);
		employee.setDepartment(department);
		employeeService.save(employee);
		LOGGER.debug("employee={}", employee);
		LOGGER.info("End");
	}

	public static void testFindTop3ByVolumeAsc() {
		LOGGER.info("Start");
		List<Stock> topStocks = stockRepository.findTop3ByCodeOrderByCloseAsc("NFLX");
		for (Stock stock : topStocks) {
			LOGGER.debug("stock={}", stock);
		}
		LOGGER.info("End");
	}

	public static void testFindTop3ByVolumeDesc() {
		LOGGER.info("Start");
		List<Stock> topStocks = stockRepository.findTop3ByOrderByVolumeDesc();
		for (Stock stock : topStocks) {
			LOGGER.debug("stock={}", stock);
		}
		LOGGER.info("End");
	}

	public static void testFindByStockGreaterThan() {
		LOGGER.info("Start");
		List<Stock> googlStocks = stockRepository.findByCodeAndCloseGreaterThan("GOOGL", new BigDecimal(1250));
		for (Stock stock : googlStocks) {
			LOGGER.debug("stock={}", stock);
		}
		LOGGER.info("End");
	}

	public static void testFindByCodeAndDateBetween() {
		LOGGER.info("Start");
		Date startDate = new GregorianCalendar(2019, Calendar.SEPTEMBER, 1).getTime();
		Date endDate = new GregorianCalendar(2019, Calendar.SEPTEMBER, 30).getTime();
		List<Stock> fbStocks = stockRepository.findByCodeAndDateBetween("FB", startDate, endDate);
		for (Stock stock : fbStocks) {
			LOGGER.debug("stock={}", stock);
		}
		LOGGER.info("End");
	}

	public static void testGetAllCountries() {
		LOGGER.info("Start");
		List<Country> countries = countryService.getAllCountries();
		LOGGER.debug("countries={}", countries);
		LOGGER.info("End");
	}

	public static void testGetCountryById() throws CountryNotFoundException {
		LOGGER.info("Start");
		Country country = countryService.findCountryById("IN");
		LOGGER.debug("country={}", country);
		LOGGER.info("End");
	}

	public static void testAddCountry() throws CountryNotFoundException {
		LOGGER.info("Start");
		Country country = new Country();
		country.setCode("ID");
		country.setName("India");
		countryService.addCountry(country);
		testGetCountryById();
		LOGGER.info("End");

	}

	public static void testUpdateCountry() throws CountryNotFoundException {
		LOGGER.info("Start");
		Country country = new Country();
		country.setCode("IN");
		country.setName("India");
		countryService.updateCountry(country);
		testGetCountryById();
		LOGGER.info("End");
	}

	public static void testDeleteCountry() {
		LOGGER.info("Start");
		countryService.deleteCountry("ID");
		LOGGER.info("End");
	}

	public static void testFindByNameContaining() {
		LOGGER.info("Start");
		List<Country> countryList = countryService.findCountriesContaining("ou");
//		LOGGER.debug("Countries={}", countryList);
		for (Country country : countryList) {
			LOGGER.debug("country={}", country);
		}
		LOGGER.info("End");
	}

	public static void testFindByNameContainingOrderByName() {
		LOGGER.info("Start");
		List<Country> countryList = countryService.findCountriesContainingOrderByName("ou");
		for (Country country : countryList) {
			LOGGER.debug("country={}", country);
		}
		LOGGER.info("End");
	}

	public static void testFindByNameStartingWith() {
		LOGGER.info("Start");
		List<Country> countryList = countryService.findCountriesStartingWith("Z");
		for (Country country : countryList) {
			LOGGER.debug("country={}", country);
		}
		LOGGER.info("End");
	}
}
